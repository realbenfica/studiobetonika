Dvor Press Kit
Thanks for covering Dvor! Here's what's in this folder.

/screenshots/
Full-resolution PNGs, in-game footage. Free to use in coverage — no compression applied, so feel free to crop or resize as needed for your layout.

/key-art/
Game cover art in three crops — vertical, horizontal, and square.

/logo/
Logo files — solid black and solid white versions, transparent background.

press-kit.pdf
Fact sheet and studio/game boilerplate in one document — ready to read or pull from directly.

LINKS (not bundled — hosted at the best available source)
Steam: https://store.steampowered.com/app/4881830/Dvor/
Trailer: https://youtu.be/-ZWJ22-pYI0
Soundtrack: https://ditto.fm/dvor

CONTACT
hello@studiobetonika.com
Studio Betonika (Art Britannia Ltd) — London, United Kingdom
